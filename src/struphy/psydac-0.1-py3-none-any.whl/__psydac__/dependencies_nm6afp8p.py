from numba import njit
  # Not supported in Python:
  # ValuedArgument
from numpy import array, zeros, zeros_like, floor
from math import cos, pi, sqrt
@njit(fastmath=True)
def assemble_scalar_nm6afp8p(global_test_basis_u_1, global_test_basis_u_2, global_test_basis_mapping_u_1, global_test_basis_mapping_u_2, global_span_u_1, global_span_u_2, global_span_mapping_u_1, global_span_mapping_u_2, global_x1, global_w1, global_x2, global_w2, test_u_p1, test_u_p2, test_mapping_u_p1, test_mapping_u_p2, n_element_1, n_element_2, k1, k2, pad_u_1, pad_u_2, global_arr_coeffs_x, global_arr_coeffs_y, global_arr_coeffs_u):

    
    local_x1 = zeros_like(global_x1[0,:])
    local_w1 = zeros_like(global_w1[0,:])
    local_x2 = zeros_like(global_x2[0,:])
    local_w2 = zeros_like(global_w2[0,:])
    arr_coeffs_x = zeros((1 + test_mapping_u_p1, 1 + test_mapping_u_p2), dtype='float64')
    arr_coeffs_y = zeros((1 + test_mapping_u_p1, 1 + test_mapping_u_p2), dtype='float64')
    arr_x = zeros((k1, k2), dtype='float64')
    arr_x_x2 = zeros((k1, k2), dtype='float64')
    arr_x_x1 = zeros((k1, k2), dtype='float64')
    arr_y = zeros((k1, k2), dtype='float64')
    arr_y_x2 = zeros((k1, k2), dtype='float64')
    arr_y_x1 = zeros((k1, k2), dtype='float64')
    arr_u = zeros((k1, k2), dtype='float64')
    arr_u_x2 = zeros((k1, k2), dtype='float64')
    arr_u_x1 = zeros((k1, k2), dtype='float64')
    arr_coeffs_u = zeros((1 + test_u_p1, 1 + test_u_p2), dtype='float64')
    
    g_el_kt9v3o = 0.0
    for i_element_1 in range(0, n_element_1, 1):
        local_x1[:] = global_x1[i_element_1,:]
        local_w1[:] = global_w1[i_element_1,:]
        span_u_1 = global_span_u_1[i_element_1]
        span_mapping_u_1 = global_span_mapping_u_1[i_element_1]
        for i_element_2 in range(0, n_element_2, 1):
            local_x2[:] = global_x2[i_element_2,:]
            local_w2[:] = global_w2[i_element_2,:]
            span_u_2 = global_span_u_2[i_element_2]
            span_mapping_u_2 = global_span_mapping_u_2[i_element_2]
            arr_y[:,:] = 0.0
            arr_x_x2[:,:] = 0.0
            arr_x_x1[:,:] = 0.0
            arr_y_x2[:,:] = 0.0
            arr_y_x1[:,:] = 0.0
            arr_x[:,:] = 0.0
            arr_coeffs_x[:,:] = global_arr_coeffs_x[2 + span_mapping_u_1 - test_mapping_u_p1:3 + span_mapping_u_1,3 + span_mapping_u_2 - test_mapping_u_p2:4 + span_mapping_u_2]
            arr_coeffs_y[:,:] = global_arr_coeffs_y[2 + span_mapping_u_1 - test_mapping_u_p1:3 + span_mapping_u_1,3 + span_mapping_u_2 - test_mapping_u_p2:4 + span_mapping_u_2]
            for i_quad_1 in range(0, k1, 1):
                for i_quad_2 in range(0, k2, 1):
                    for i_basis_1 in range(0, 3, 1):
                        mapping_u_1 = global_test_basis_mapping_u_1[i_element_1,i_basis_1,0,i_quad_1]
                        mapping_u_1_x1 = global_test_basis_mapping_u_1[i_element_1,i_basis_1,1,i_quad_1]
                        for i_basis_2 in range(0, 4, 1):
                            mapping_u_2 = global_test_basis_mapping_u_2[i_element_2,i_basis_2,0,i_quad_2]
                            mapping_u_2_x2 = global_test_basis_mapping_u_2[i_element_2,i_basis_2,1,i_quad_2]
                            coeff_x = arr_coeffs_x[i_basis_1,i_basis_2]
                            coeff_y = arr_coeffs_y[i_basis_1,i_basis_2]
                            mapping_u_x2 = mapping_u_1*mapping_u_2_x2
                            mapping_u_x1 = mapping_u_1_x1*mapping_u_2
                            mapping_u = mapping_u_1*mapping_u_2
                            arr_x[i_quad_1,i_quad_2] += mapping_u*coeff_x
                            arr_x_x2[i_quad_1,i_quad_2] += mapping_u_x2*coeff_x
                            arr_x_x1[i_quad_1,i_quad_2] += mapping_u_x1*coeff_x
                            arr_y[i_quad_1,i_quad_2] += mapping_u*coeff_y
                            arr_y_x2[i_quad_1,i_quad_2] += mapping_u_x2*coeff_y
                            arr_y_x1[i_quad_1,i_quad_2] += mapping_u_x1*coeff_y
                        
                    
                
            
            arr_u[:,:] = 0.0
            arr_u_x2[:,:] = 0.0
            arr_u_x1[:,:] = 0.0
            arr_coeffs_u[:,:] = global_arr_coeffs_u[pad_u_1 + span_u_1 - test_u_p1:1 + pad_u_1 + span_u_1,pad_u_2 + span_u_2 - test_u_p2:1 + pad_u_2 + span_u_2]
            for i_basis_1 in range(0, 1 + test_u_p1, 1):
                for i_basis_2 in range(0, 1 + test_u_p2, 1):
                    coeff_u = arr_coeffs_u[i_basis_1,i_basis_2]
                    for i_quad_1 in range(0, k1, 1):
                        u_1 = global_test_basis_u_1[i_element_1,i_basis_1,0,i_quad_1]
                        u_1_x1 = global_test_basis_u_1[i_element_1,i_basis_1,1,i_quad_1]
                        for i_quad_2 in range(0, k2, 1):
                            u_2 = global_test_basis_u_2[i_element_2,i_basis_2,0,i_quad_2]
                            u_2_x2 = global_test_basis_u_2[i_element_2,i_basis_2,1,i_quad_2]
                            u = u_1*u_2
                            u_x2 = u_1*u_2_x2
                            u_x1 = u_1_x1*u_2
                            arr_u[i_quad_1,i_quad_2] += u*coeff_u
                            arr_u_x2[i_quad_1,i_quad_2] += u_x2*coeff_u
                            arr_u_x1[i_quad_1,i_quad_2] += u_x1*coeff_u
                        
                    
                
            
            l_el_bkb4dl = 0.0
            for i_quad_1 in range(0, k1, 1):
                x1 = local_x1[i_quad_1]
                w1 = local_w1[i_quad_1]
                for i_quad_2 in range(0, k2, 1):
                    x2 = local_x2[i_quad_2]
                    w2 = local_w2[i_quad_2]
                    x = arr_x[i_quad_1,i_quad_2]
                    x_x2 = arr_x_x2[i_quad_1,i_quad_2]
                    x_x1 = arr_x_x1[i_quad_1,i_quad_2]
                    y = arr_y[i_quad_1,i_quad_2]
                    y_x2 = arr_y_x2[i_quad_1,i_quad_2]
                    y_x1 = arr_y_x1[i_quad_1,i_quad_2]
                    wvol_mapping_0 = w1*w2
                    u = arr_u[i_quad_1,i_quad_2]
                    u_x2 = arr_u_x2[i_quad_1,i_quad_2]
                    u_x1 = arr_u_x1[i_quad_1,i_quad_2]
                    temp0 = 2*pi
                    l_el_bkb4dl += wvol_mapping_0*(u + (x**2 + y**2 - 1)*cos(temp0*x)*cos(temp0*y))**2*sqrt((x_x1*y_x2 - x_x2*y_x1)**2)
                
            
            g_el_kt9v3o += l_el_bkb4dl
        
    
    return g_el_kt9v3o