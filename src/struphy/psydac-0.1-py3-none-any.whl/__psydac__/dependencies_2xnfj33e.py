from pyccel.decorators import types
@types("float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "int64[:]", "int64[:]", "int64[:]", "int64[:]", "float64[:,:]", "float64[:,:]", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "int64", "int64", "int64", "int64")
def assemble_matrix_2xnfj33e(global_test_basis_v_0_1, global_test_basis_v_0_2, global_test_basis_v_1_1, global_test_basis_v_1_2, global_trial_basis_u_0_1, global_trial_basis_u_0_2, global_trial_basis_u_1_1, global_trial_basis_u_1_2, global_span_v_0_1, global_span_v_0_2, global_span_v_1_1, global_span_v_1_2, global_x1, global_x2, test_v_0_p1, test_v_0_p2, test_v_1_p1, test_v_1_p2, trial_u_0_p1, trial_u_0_p2, trial_u_1_p1, trial_u_1_p2, n_element_1, n_element_2, k1, k2, pad1, pad2, g_mat_u_0_v_0_2xnfj33e, g_mat_u_1_v_0_2xnfj33e, g_mat_u_0_v_1_2xnfj33e, g_mat_u_1_v_1_2xnfj33e, b01, b02, e01, e02):

    from numpy import array, zeros, zeros_like, floor
    from math import cos, sin, sqrt
    local_x1 = zeros_like(global_x1[0,:])
    local_x2 = zeros_like(global_x2[0,:])
    
    l_mat_u_0_v_0_2xnfj33e = zeros((2, 3, 3, 5), dtype='float64')
    l_mat_u_0_v_1_2xnfj33e = zeros((3, 2, 5, 5), dtype='float64')
    l_mat_u_1_v_0_2xnfj33e = zeros((2, 3, 5, 5), dtype='float64')
    l_mat_u_1_v_1_2xnfj33e = zeros((3, 2, 5, 3), dtype='float64')
    i_element_1 = 0
    local_x1[:] = global_x1[i_element_1,:]
    span_v_0_1 = global_span_v_0_1[i_element_1]
    span_v_1_1 = global_span_v_1_1[i_element_1]
    for i_element_2 in range(0, n_element_2, 1):
        local_x2[:] = global_x2[i_element_2,:]
        span_v_0_2 = global_span_v_0_2[i_element_2]
        span_v_1_2 = global_span_v_1_2[i_element_2]
        for i_basis_1 in range(0, 2, 1):
            for i_basis_2 in range(0, 3, 1):
                for j_basis_1 in range(0, 2, 1):
                    for j_basis_2 in range(0, 3, 1):
                        contribution_v_0_u_0_2xnfj33e = 0.0
                        i_quad_1 = 0
                        x1 = local_x1[i_quad_1]
                        v_0_1 = global_test_basis_v_0_1[i_element_1,i_basis_1,0,i_quad_1]
                        v_0_1_x1 = global_test_basis_v_0_1[i_element_1,i_basis_1,1,i_quad_1]
                        u_0_1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,0,i_quad_1]
                        u_0_1_x1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,1,i_quad_1]
                        for i_quad_2 in range(0, 3, 1):
                            x2 = local_x2[i_quad_2]
                            v_0_2 = global_test_basis_v_0_2[i_element_2,i_basis_2,0,i_quad_2]
                            v_0_2_x2 = global_test_basis_v_0_2[i_element_2,i_basis_2,1,i_quad_2]
                            u_0_2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,0,i_quad_2]
                            u_0_2_x2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,1,i_quad_2]
                            v_0 = v_0_1*v_0_2
                            v_0_x2 = v_0_1*v_0_2_x2
                            v_0_x1 = v_0_1_x1*v_0_2
                            u_0 = u_0_1*u_0_2
                            u_0_x2 = u_0_1*u_0_2_x2
                            u_0_x1 = u_0_1_x1*u_0_2
                            nn_0 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*cos(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            nn_1 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*sin(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            temp0 = sin(x2)
                            temp1 = temp0**2
                            temp2 = cos(x2)
                            temp3 = temp2**2
                            temp4 = temp1 + temp3
                            temp5 = 1.0/(1.0*temp1 + 1.0*temp3)
                            temp6 = temp5*v_0
                            temp7 = nn_0*temp0
                            temp8 = nn_1*temp2
                            temp9 = -temp6*temp7 + temp6*temp8
                            temp10 = temp5*u_0
                            temp11 = -temp10*temp7 + temp10*temp8
                            contribution_v_0_u_0_2xnfj33e += 1.0*sqrt(temp4*x1**2)*(80.0*temp11*temp4*temp9*x1 - temp11*v_0_x2 - temp9*u_0_x2)/(temp4*x1)
                        
                        l_mat_u_0_v_0_2xnfj33e[i_basis_1,i_basis_2,1 - i_basis_1 + j_basis_1,2 - i_basis_2 + j_basis_2] = contribution_v_0_u_0_2xnfj33e
                    
                
            
        
        for i_basis_1 in range(0, 2, 1):
            for i_basis_2 in range(0, 3, 1):
                for j_basis_1 in range(0, 3, 1):
                    for j_basis_2 in range(0, 2, 1):
                        contribution_v_0_u_1_2xnfj33e = 0.0
                        i_quad_1 = 0
                        x1 = local_x1[i_quad_1]
                        v_0_1 = global_test_basis_v_0_1[i_element_1,i_basis_1,0,i_quad_1]
                        v_0_1_x1 = global_test_basis_v_0_1[i_element_1,i_basis_1,1,i_quad_1]
                        u_1_1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,0,i_quad_1]
                        u_1_1_x1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,1,i_quad_1]
                        for i_quad_2 in range(0, 3, 1):
                            x2 = local_x2[i_quad_2]
                            v_0_2 = global_test_basis_v_0_2[i_element_2,i_basis_2,0,i_quad_2]
                            v_0_2_x2 = global_test_basis_v_0_2[i_element_2,i_basis_2,1,i_quad_2]
                            u_1_2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,0,i_quad_2]
                            u_1_2_x2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,1,i_quad_2]
                            v_0 = v_0_1*v_0_2
                            v_0_x2 = v_0_1*v_0_2_x2
                            v_0_x1 = v_0_1_x1*v_0_2
                            u_1 = u_1_1*u_1_2
                            u_1_x2 = u_1_1*u_1_2_x2
                            u_1_x1 = u_1_1_x1*u_1_2
                            nn_0 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*cos(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            nn_1 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*sin(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            temp0 = sin(x2)
                            temp1 = temp0**2
                            temp2 = cos(x2)
                            temp3 = temp2**2
                            temp4 = temp1 + temp3
                            temp5 = 1.0*temp1
                            temp6 = 1.0*temp3
                            temp7 = v_0/(temp5 + temp6)
                            temp8 = 1.0*temp0
                            temp9 = 1.0*temp2
                            temp10 = -nn_0*temp7*temp8 + nn_1*temp7*temp9
                            temp11 = u_1/(temp5*x1 + temp6*x1)
                            temp12 = -nn_0*temp11*temp9 - nn_1*temp11*temp8
                            contribution_v_0_u_1_2xnfj33e += 1.0*sqrt(temp4*x1**2)*(80.0*temp10*temp12*temp4*x1 + temp10*u_1_x1 - temp12*v_0_x2)/(temp4*x1)
                        
                        l_mat_u_1_v_0_2xnfj33e[i_basis_1,i_basis_2,2 - i_basis_1 + j_basis_1,2 - i_basis_2 + j_basis_2] = contribution_v_0_u_1_2xnfj33e
                    
                
            
        
        for i_basis_1 in range(0, 3, 1):
            for i_basis_2 in range(0, 2, 1):
                for j_basis_1 in range(0, 2, 1):
                    for j_basis_2 in range(0, 3, 1):
                        contribution_v_1_u_0_2xnfj33e = 0.0
                        i_quad_1 = 0
                        x1 = local_x1[i_quad_1]
                        v_1_1 = global_test_basis_v_1_1[i_element_1,i_basis_1,0,i_quad_1]
                        v_1_1_x1 = global_test_basis_v_1_1[i_element_1,i_basis_1,1,i_quad_1]
                        u_0_1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,0,i_quad_1]
                        u_0_1_x1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,1,i_quad_1]
                        for i_quad_2 in range(0, 3, 1):
                            x2 = local_x2[i_quad_2]
                            v_1_2 = global_test_basis_v_1_2[i_element_2,i_basis_2,0,i_quad_2]
                            v_1_2_x2 = global_test_basis_v_1_2[i_element_2,i_basis_2,1,i_quad_2]
                            u_0_2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,0,i_quad_2]
                            u_0_2_x2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,1,i_quad_2]
                            v_1 = v_1_1*v_1_2
                            v_1_x2 = v_1_1*v_1_2_x2
                            v_1_x1 = v_1_1_x1*v_1_2
                            u_0 = u_0_1*u_0_2
                            u_0_x2 = u_0_1*u_0_2_x2
                            u_0_x1 = u_0_1_x1*u_0_2
                            nn_0 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*cos(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            nn_1 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*sin(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            temp0 = sin(x2)
                            temp1 = temp0**2
                            temp2 = cos(x2)
                            temp3 = temp2**2
                            temp4 = temp1 + temp3
                            temp5 = 1.0*temp1
                            temp6 = 1.0*temp3
                            temp7 = u_0/(temp5 + temp6)
                            temp8 = 1.0*temp0
                            temp9 = 1.0*temp2
                            temp10 = -nn_0*temp7*temp8 + nn_1*temp7*temp9
                            temp11 = v_1/(temp5*x1 + temp6*x1)
                            temp12 = -nn_0*temp11*temp9 - nn_1*temp11*temp8
                            contribution_v_1_u_0_2xnfj33e += 1.0*sqrt(temp4*x1**2)*(80.0*temp10*temp12*temp4*x1 + temp10*v_1_x1 - temp12*u_0_x2)/(temp4*x1)
                        
                        l_mat_u_0_v_1_2xnfj33e[i_basis_1,i_basis_2,2 - i_basis_1 + j_basis_1,2 - i_basis_2 + j_basis_2] = contribution_v_1_u_0_2xnfj33e
                    
                
            
        
        for i_basis_1 in range(0, 3, 1):
            for i_basis_2 in range(0, 2, 1):
                for j_basis_1 in range(0, 3, 1):
                    for j_basis_2 in range(0, 2, 1):
                        contribution_v_1_u_1_2xnfj33e = 0.0
                        i_quad_1 = 0
                        x1 = local_x1[i_quad_1]
                        v_1_1 = global_test_basis_v_1_1[i_element_1,i_basis_1,0,i_quad_1]
                        v_1_1_x1 = global_test_basis_v_1_1[i_element_1,i_basis_1,1,i_quad_1]
                        u_1_1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,0,i_quad_1]
                        u_1_1_x1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,1,i_quad_1]
                        for i_quad_2 in range(0, 3, 1):
                            x2 = local_x2[i_quad_2]
                            v_1_2 = global_test_basis_v_1_2[i_element_2,i_basis_2,0,i_quad_2]
                            v_1_2_x2 = global_test_basis_v_1_2[i_element_2,i_basis_2,1,i_quad_2]
                            u_1_2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,0,i_quad_2]
                            u_1_2_x2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,1,i_quad_2]
                            v_1 = v_1_1*v_1_2
                            v_1_x2 = v_1_1*v_1_2_x2
                            v_1_x1 = v_1_1_x1*v_1_2
                            u_1 = u_1_1*u_1_2
                            u_1_x2 = u_1_1*u_1_2_x2
                            u_1_x1 = u_1_1_x1*u_1_2
                            nn_0 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*cos(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            nn_1 = 1.0*(1.0*sin(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2 + 1.0*cos(x2)**2/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)**2)**(-0.5)*sin(x2)/(1.0*sin(x2)**2 + 1.0*cos(x2)**2)
                            temp0 = sin(x2)
                            temp1 = temp0**2
                            temp2 = cos(x2)
                            temp3 = temp2**2
                            temp4 = temp1 + temp3
                            temp5 = 1.0*x1
                            temp6 = 1.0/(temp1*temp5 + temp3*temp5)
                            temp7 = temp6*v_1
                            temp8 = nn_0*temp2
                            temp9 = nn_1*temp0
                            temp10 = -temp7*temp8 - temp7*temp9
                            temp11 = temp6*u_1
                            temp12 = -temp11*temp8 - temp11*temp9
                            contribution_v_1_u_1_2xnfj33e += 1.0*sqrt(temp4*x1**2)*(80.0*temp10*temp12*temp4*x1 + temp10*u_1_x1 + temp12*v_1_x1)/(temp4*x1)
                        
                        l_mat_u_1_v_1_2xnfj33e[i_basis_1,i_basis_2,2 - i_basis_1 + j_basis_1,1 - i_basis_2 + j_basis_2] = contribution_v_1_u_1_2xnfj33e
                    
                
            
        
        g_mat_u_0_v_0_2xnfj33e[pad1 + span_v_0_1 - test_v_0_p1:1 + pad1 + span_v_0_1,pad2 + span_v_0_2 - test_v_0_p2:1 + pad2 + span_v_0_2,:,:] += l_mat_u_0_v_0_2xnfj33e[:,:,:,:]
        g_mat_u_1_v_0_2xnfj33e[pad1 + span_v_0_1 - test_v_0_p1:1 + pad1 + span_v_0_1,pad2 + span_v_0_2 - test_v_0_p2:1 + pad2 + span_v_0_2,:,:] += l_mat_u_1_v_0_2xnfj33e[:,:,:,:]
        g_mat_u_0_v_1_2xnfj33e[pad1 + span_v_1_1 - test_v_1_p1:1 + pad1 + span_v_1_1,pad2 + span_v_1_2 - test_v_1_p2:1 + pad2 + span_v_1_2,:,:] += l_mat_u_0_v_1_2xnfj33e[:,:,:,:]
        g_mat_u_1_v_1_2xnfj33e[pad1 + span_v_1_1 - test_v_1_p1:1 + pad1 + span_v_1_1,pad2 + span_v_1_2 - test_v_1_p2:1 + pad2 + span_v_1_2,:,:] += l_mat_u_1_v_1_2xnfj33e[:,:,:,:]
    
    return