
def assemble_vector_70b7faye(global_test_basis_v_1, global_test_basis_v_2, global_span_v_1, global_span_v_2, global_x1, global_x2, test_v_p1, test_v_p2, n_element_1, n_element_2, k1, k2, pad1, pad2, g_vec_v_70b7faye):

    from numpy import array, zeros, zeros_like, floor
    from math import sin, cos, pi
    local_x1 = zeros_like(global_x1[0,:])
    local_x2 = zeros_like(global_x2[0,:])
    
    l_vec_v_70b7faye = zeros((4, 4), dtype='float64')
    for i_element_1 in range(0, n_element_1, 1):
        local_x1[:] = global_x1[i_element_1,:]
        span_v_1 = global_span_v_1[i_element_1]
        for i_element_2 in range(0, n_element_2, 1):
            local_x2[:] = global_x2[i_element_2,:]
            span_v_2 = global_span_v_2[i_element_2]
            for i_basis_1 in range(0, 1 + test_v_p1, 1):
                for i_basis_2 in range(0, 1 + test_v_p2, 1):
                    contribution_v_70b7faye = 0.0
                    for i_quad_1 in range(0, 4, 1):
                        x1 = local_x1[i_quad_1]
                        v_1 = global_test_basis_v_1[i_element_1,i_basis_1,0,i_quad_1]
                        v_1_x1 = global_test_basis_v_1[i_element_1,i_basis_1,1,i_quad_1]
                        for i_quad_2 in range(0, 4, 1):
                            x2 = local_x2[i_quad_2]
                            v_2 = global_test_basis_v_2[i_element_2,i_basis_2,0,i_quad_2]
                            v_2_x2 = global_test_basis_v_2[i_element_2,i_basis_2,1,i_quad_2]
                            v = v_1*v_2
                            v_x2 = v_1*v_2_x2
                            v_x1 = v_1_x1*v_2
                            temp0 = pi**4
                            temp1 = pi*x1
                            temp2 = sin(temp1)**2
                            temp3 = pi*x2
                            temp4 = sin(temp3)**2
                            temp5 = cos(temp3)**2
                            temp6 = 16*temp0
                            temp7 = cos(temp1)**2
                            contribution_v_70b7faye += v*(24*temp0*temp2*temp4 + 8*temp0*temp5*temp7 - temp2*temp5*temp6 - temp4*temp6*temp7)
                        
                    
                    l_vec_v_70b7faye[i_basis_1,i_basis_2] = contribution_v_70b7faye
                
            
            g_vec_v_70b7faye[pad1 + span_v_1 - test_v_p1:1 + pad1 + span_v_1,pad2 + span_v_2 - test_v_p2:1 + pad2 + span_v_2] += l_vec_v_70b7faye[:,:]
        
    
    return