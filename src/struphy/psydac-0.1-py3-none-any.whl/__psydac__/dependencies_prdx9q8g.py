from pyccel.decorators import types
from numpy import shape
@types("float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:]", "float64[:,:]", "float64[:,:]", "float64[:,:]")
def lo_dot_prdx9q8g(mat00, mat01, mat10, mat11, x0, x1, out0, out1):

    
    for i1 in range(0, 9, 1):
        for i2 in range(0, 3, 1):
            v00 = 0.0
            for k1 in range(0, 3, 1):
                for k2 in range(0, 5, 1):
                    v00 += mat00[2 + i1,2 + i2,k1,k2]*x0[1 + i1 + k1,i2 + k2]
                
            
            out0[2 + i1,2 + i2] = v00
        
    
    for i1 in range(0, 10, 1):
        for i2 in range(0, 1, 1):
            v11 = 0.0
            for k1 in range(0, 5, 1):
                for k2 in range(0, 3, 1):
                    v11 += mat11[2 + i1,2 + i2,k1,k2]*x1[i1 + k1,1 + i2 + k2]
                
            
            out1[2 + i1,2 + i2] = v11
        
    
    for i1 in range(0, 9, 1):
        for i2 in range(0, 2, 1):
            v01 = 0.0
            for k1 in range(0, 5, 1):
                for k2 in range(0, 5, 1):
                    v01 += mat01[2 + i1,2 + i2,k1,k2]*x1[i1 + k1,i2 + k2]
                
            
            out0[2 + i1,2 + i2] += v01
        
    
    for i1 in range(0, 9, 1):
        for i2 in range(0, 1, 1):
            v01 = 0.0
            for k1 in range(0, 5 - max(0, i1 - 8), 1):
                for k2 in range(0, 4 - i2, 1):
                    v01 += x1[i1 + k1,2 + i2 + k2]*mat01[2 + i1,4 + i2,k1,k2]
                
            
            out0[2 + i1,4 + i2] += v01
        
    
    for i1 in range(0, 9, 1):
        for i2 in range(0, 2, 1):
            v10 = 0.0
            for k1 in range(0, 5, 1):
                for k2 in range(0, 5, 1):
                    v10 += mat10[2 + i1,2 + i2,k1,k2]*x0[i1 + k1,i2 + k2]
                
            
            out1[2 + i1,2 + i2] += v10
        
    
    for i1 in range(0, 1, 1):
        for i2 in range(0, 2, 1):
            v10 = 0.0
            for k1 in range(0, 4 - i1, 1):
                for k2 in range(0, 5, 1):
                    v10 += x0[9 + i1 + k1,i2 + k2]*mat10[11 + i1,2 + i2,k1,k2]
                
            
            out1[11 + i1,2 + i2] += v10
        
    
    return