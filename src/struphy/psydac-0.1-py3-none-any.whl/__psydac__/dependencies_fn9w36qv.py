
def assemble_matrix_fn9w36qv(global_test_basis_v_1, global_test_basis_v_2, global_trial_basis_u_1, global_trial_basis_u_2, global_span_v_1, global_span_v_2, global_x1, global_x2, test_v_p1, test_v_p2, trial_u_p1, trial_u_p2, n_element_1, n_element_2, k1, k2, pad1, pad2, g_mat_u_v_fn9w36qv, b01, b02, e01, e02):

    from numpy import array, zeros, zeros_like, floor
    local_x1 = zeros_like(global_x1[0,:])
    local_x2 = zeros_like(global_x2[0,:])
    
    l_mat_u_v_fn9w36qv = zeros((3, 3, 5, 5), dtype='float64')
    for i_element_1 in range(0, n_element_1, 1):
        local_x1[:] = global_x1[i_element_1,:]
        span_v_1 = global_span_v_1[i_element_1]
        for i_element_2 in range(0, n_element_2, 1):
            local_x2[:] = global_x2[i_element_2,:]
            span_v_2 = global_span_v_2[i_element_2]
            for i_basis_1 in range(0, 3, 1):
                for i_basis_2 in range(0, 3, 1):
                    for j_basis_1 in range(0, 3, 1):
                        for j_basis_2 in range(0, 3, 1):
                            contribution_v_u_fn9w36qv = 0.0
                            for i_quad_1 in range(0, 3, 1):
                                x1 = local_x1[i_quad_1]
                                v_1 = global_test_basis_v_1[i_element_1,i_basis_1,0,i_quad_1]
                                v_1_x1 = global_test_basis_v_1[i_element_1,i_basis_1,1,i_quad_1]
                                u_1 = global_trial_basis_u_1[i_element_1,j_basis_1,0,i_quad_1]
                                u_1_x1 = global_trial_basis_u_1[i_element_1,j_basis_1,1,i_quad_1]
                                for i_quad_2 in range(0, 3, 1):
                                    x2 = local_x2[i_quad_2]
                                    v_2 = global_test_basis_v_2[i_element_2,i_basis_2,0,i_quad_2]
                                    v_2_x2 = global_test_basis_v_2[i_element_2,i_basis_2,1,i_quad_2]
                                    u_2 = global_trial_basis_u_2[i_element_2,j_basis_2,0,i_quad_2]
                                    u_2_x2 = global_trial_basis_u_2[i_element_2,j_basis_2,1,i_quad_2]
                                    v = v_1*v_2
                                    v_x2 = v_1*v_2_x2
                                    v_x1 = v_1_x1*v_2
                                    u = u_1*u_2
                                    u_x2 = u_1*u_2_x2
                                    u_x1 = u_1_x1*u_2
                                    contribution_v_u_fn9w36qv += u*v + u_x1*v_x1 + u_x2*v_x2
                                
                            
                            l_mat_u_v_fn9w36qv[i_basis_1,i_basis_2,2 - i_basis_1 + j_basis_1,2 - i_basis_2 + j_basis_2] = contribution_v_u_fn9w36qv
                        
                    
                
            
            g_mat_u_v_fn9w36qv[pad1 + span_v_1 - test_v_p1:1 + pad1 + span_v_1,pad2 + span_v_2 - test_v_p2:1 + pad2 + span_v_2,:,:] += l_mat_u_v_fn9w36qv[:,:,:,:]
        
    
    return