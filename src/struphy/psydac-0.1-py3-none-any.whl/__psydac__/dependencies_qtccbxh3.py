from numba import njit
from numpy import shape
  # Not supported in Python:
  # ValuedArgument
@njit(fastmath=True)
def lo_dot_qtccbxh3(mat00, x0, out0, s00_1, s00_2, n00_1, n00_2):

    
    b1 = 2 - s00_1 % 2
    b2 = 2 - s00_2 % 2
    for i1 in range(0, n00_1, 1):
        for i2 in range(0, n00_2, 1):
            v00 = 0.0
            for k1 in range(0, 5, 1):
                for k2 in range(0, 5, 1):
                    v00 += mat00[4 + i1,4 + i2,k1,k2]*x0[b1 + k1 + 2*((s00_1 % 2 + i1)//(2)),b2 + k2 + 2*((s00_2 % 2 + i2)//(2))]
                
            
            out0[4 + i1,4 + i2] = v00
        
    
    return