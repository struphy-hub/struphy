from pyccel.decorators import types
@types("float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "int64[:]", "int64[:]", "int64[:]", "int64[:]", "float64[:,:]", "float64[:,:]", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "int64", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "float64[:,:,:,:]", "int64", "int64", "int64", "int64")
def assemble_matrix_0bdquykp(global_test_basis_v_0_1, global_test_basis_v_0_2, global_test_basis_v_1_1, global_test_basis_v_1_2, global_trial_basis_u_0_1, global_trial_basis_u_0_2, global_trial_basis_u_1_1, global_trial_basis_u_1_2, global_span_v_0_1, global_span_v_0_2, global_span_v_1_1, global_span_v_1_2, global_x1, global_x2, test_v_0_p1, test_v_0_p2, test_v_1_p1, test_v_1_p2, trial_u_0_p1, trial_u_0_p2, trial_u_1_p1, trial_u_1_p2, n_element_1, n_element_2, k1, k2, pad1, pad2, g_mat_u_0_v_0_0bdquykp, g_mat_u_1_v_0_0bdquykp, g_mat_u_0_v_1_0bdquykp, g_mat_u_1_v_1_0bdquykp, b01, b02, e01, e02):

    from numpy import array, zeros, zeros_like, floor
    from math import cos, sin, sqrt
    local_x1 = zeros_like(global_x1[0,:])
    local_x2 = zeros_like(global_x2[0,:])
    
    l_mat_u_0_v_0_0bdquykp = zeros((2, 3, 3, 5), dtype='float64')
    l_mat_u_0_v_1_0bdquykp = zeros((3, 2, 5, 5), dtype='float64')
    l_mat_u_1_v_0_0bdquykp = zeros((2, 3, 5, 5), dtype='float64')
    l_mat_u_1_v_1_0bdquykp = zeros((3, 2, 5, 3), dtype='float64')
    for i_element_1 in range(0, n_element_1, 1):
        local_x1[:] = global_x1[i_element_1,:]
        span_v_0_1 = global_span_v_0_1[i_element_1]
        span_v_1_1 = global_span_v_1_1[i_element_1]
        for i_element_2 in range(0, n_element_2, 1):
            local_x2[:] = global_x2[i_element_2,:]
            span_v_0_2 = global_span_v_0_2[i_element_2]
            span_v_1_2 = global_span_v_1_2[i_element_2]
            for i_basis_1 in range(0, 2, 1):
                for i_basis_2 in range(0, 3, 1):
                    for j_basis_1 in range(0, 2, 1):
                        for j_basis_2 in range(0, 3, 1):
                            contribution_v_0_u_0_0bdquykp = 0.0
                            for i_quad_1 in range(0, 3, 1):
                                x1 = local_x1[i_quad_1]
                                v_0_1 = global_test_basis_v_0_1[i_element_1,i_basis_1,0,i_quad_1]
                                v_0_1_x1 = global_test_basis_v_0_1[i_element_1,i_basis_1,1,i_quad_1]
                                u_0_1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,0,i_quad_1]
                                u_0_1_x1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,1,i_quad_1]
                                for i_quad_2 in range(0, 3, 1):
                                    x2 = local_x2[i_quad_2]
                                    v_0_2 = global_test_basis_v_0_2[i_element_2,i_basis_2,0,i_quad_2]
                                    v_0_2_x2 = global_test_basis_v_0_2[i_element_2,i_basis_2,1,i_quad_2]
                                    u_0_2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,0,i_quad_2]
                                    u_0_2_x2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,1,i_quad_2]
                                    v_0 = v_0_1*v_0_2
                                    v_0_x2 = v_0_1*v_0_2_x2
                                    v_0_x1 = v_0_1_x1*v_0_2
                                    u_0 = u_0_1*u_0_2
                                    u_0_x2 = u_0_1*u_0_2_x2
                                    u_0_x1 = u_0_1_x1*u_0_2
                                    temp0 = x1**2
                                    temp1 = sin(x2)**2
                                    temp2 = cos(x2)**2
                                    temp3 = (temp1 + temp2)**2
                                    temp4 = 1.0*temp1
                                    temp5 = 1.0*temp2
                                    temp6 = (temp4 + temp5)**2
                                    temp7 = u_0*v_0/temp6
                                    contribution_v_0_u_0_0bdquykp += 1.0*sqrt(temp0*temp6)*(-2.25*temp0*temp3*(temp4*temp7 + temp5*temp7) + u_0_x2*v_0_x2)/(temp0*temp3)
                                
                            
                            l_mat_u_0_v_0_0bdquykp[i_basis_1,i_basis_2,1 - i_basis_1 + j_basis_1,2 - i_basis_2 + j_basis_2] = contribution_v_0_u_0_0bdquykp
                        
                    
                
            
            for i_basis_1 in range(0, 2, 1):
                for i_basis_2 in range(0, 3, 1):
                    for j_basis_1 in range(0, 3, 1):
                        for j_basis_2 in range(0, 2, 1):
                            contribution_v_0_u_1_0bdquykp = 0.0
                            for i_quad_1 in range(0, 3, 1):
                                x1 = local_x1[i_quad_1]
                                v_0_1 = global_test_basis_v_0_1[i_element_1,i_basis_1,0,i_quad_1]
                                v_0_1_x1 = global_test_basis_v_0_1[i_element_1,i_basis_1,1,i_quad_1]
                                u_1_1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,0,i_quad_1]
                                u_1_1_x1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,1,i_quad_1]
                                for i_quad_2 in range(0, 3, 1):
                                    x2 = local_x2[i_quad_2]
                                    v_0_2 = global_test_basis_v_0_2[i_element_2,i_basis_2,0,i_quad_2]
                                    v_0_2_x2 = global_test_basis_v_0_2[i_element_2,i_basis_2,1,i_quad_2]
                                    u_1_2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,0,i_quad_2]
                                    u_1_2_x2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,1,i_quad_2]
                                    v_0 = v_0_1*v_0_2
                                    v_0_x2 = v_0_1*v_0_2_x2
                                    v_0_x1 = v_0_1_x1*v_0_2
                                    u_1 = u_1_1*u_1_2
                                    u_1_x2 = u_1_1*u_1_2_x2
                                    u_1_x1 = u_1_1_x1*u_1_2
                                    temp0 = x1**2
                                    temp1 = sin(x2)**2
                                    temp2 = cos(x2)**2
                                    contribution_v_0_u_1_0bdquykp += -1.0*u_1_x1*v_0_x2*sqrt(temp0*(1.0*temp1 + 1.0*temp2)**2)/(temp0*(temp1 + temp2)**2)
                                
                            
                            l_mat_u_1_v_0_0bdquykp[i_basis_1,i_basis_2,2 - i_basis_1 + j_basis_1,2 - i_basis_2 + j_basis_2] = contribution_v_0_u_1_0bdquykp
                        
                    
                
            
            for i_basis_1 in range(0, 3, 1):
                for i_basis_2 in range(0, 2, 1):
                    for j_basis_1 in range(0, 2, 1):
                        for j_basis_2 in range(0, 3, 1):
                            contribution_v_1_u_0_0bdquykp = 0.0
                            for i_quad_1 in range(0, 3, 1):
                                x1 = local_x1[i_quad_1]
                                v_1_1 = global_test_basis_v_1_1[i_element_1,i_basis_1,0,i_quad_1]
                                v_1_1_x1 = global_test_basis_v_1_1[i_element_1,i_basis_1,1,i_quad_1]
                                u_0_1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,0,i_quad_1]
                                u_0_1_x1 = global_trial_basis_u_0_1[i_element_1,j_basis_1,1,i_quad_1]
                                for i_quad_2 in range(0, 3, 1):
                                    x2 = local_x2[i_quad_2]
                                    v_1_2 = global_test_basis_v_1_2[i_element_2,i_basis_2,0,i_quad_2]
                                    v_1_2_x2 = global_test_basis_v_1_2[i_element_2,i_basis_2,1,i_quad_2]
                                    u_0_2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,0,i_quad_2]
                                    u_0_2_x2 = global_trial_basis_u_0_2[i_element_2,j_basis_2,1,i_quad_2]
                                    v_1 = v_1_1*v_1_2
                                    v_1_x2 = v_1_1*v_1_2_x2
                                    v_1_x1 = v_1_1_x1*v_1_2
                                    u_0 = u_0_1*u_0_2
                                    u_0_x2 = u_0_1*u_0_2_x2
                                    u_0_x1 = u_0_1_x1*u_0_2
                                    temp0 = x1**2
                                    temp1 = sin(x2)**2
                                    temp2 = cos(x2)**2
                                    contribution_v_1_u_0_0bdquykp += -1.0*u_0_x2*v_1_x1*sqrt(temp0*(1.0*temp1 + 1.0*temp2)**2)/(temp0*(temp1 + temp2)**2)
                                
                            
                            l_mat_u_0_v_1_0bdquykp[i_basis_1,i_basis_2,2 - i_basis_1 + j_basis_1,2 - i_basis_2 + j_basis_2] = contribution_v_1_u_0_0bdquykp
                        
                    
                
            
            for i_basis_1 in range(0, 3, 1):
                for i_basis_2 in range(0, 2, 1):
                    for j_basis_1 in range(0, 3, 1):
                        for j_basis_2 in range(0, 2, 1):
                            contribution_v_1_u_1_0bdquykp = 0.0
                            for i_quad_1 in range(0, 3, 1):
                                x1 = local_x1[i_quad_1]
                                v_1_1 = global_test_basis_v_1_1[i_element_1,i_basis_1,0,i_quad_1]
                                v_1_1_x1 = global_test_basis_v_1_1[i_element_1,i_basis_1,1,i_quad_1]
                                u_1_1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,0,i_quad_1]
                                u_1_1_x1 = global_trial_basis_u_1_1[i_element_1,j_basis_1,1,i_quad_1]
                                for i_quad_2 in range(0, 3, 1):
                                    x2 = local_x2[i_quad_2]
                                    v_1_2 = global_test_basis_v_1_2[i_element_2,i_basis_2,0,i_quad_2]
                                    v_1_2_x2 = global_test_basis_v_1_2[i_element_2,i_basis_2,1,i_quad_2]
                                    u_1_2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,0,i_quad_2]
                                    u_1_2_x2 = global_trial_basis_u_1_2[i_element_2,j_basis_2,1,i_quad_2]
                                    v_1 = v_1_1*v_1_2
                                    v_1_x2 = v_1_1*v_1_2_x2
                                    v_1_x1 = v_1_1_x1*v_1_2
                                    u_1 = u_1_1*u_1_2
                                    u_1_x2 = u_1_1*u_1_2_x2
                                    u_1_x1 = u_1_1_x1*u_1_2
                                    temp0 = x1**2
                                    temp1 = sin(x2)**2
                                    temp2 = cos(x2)**2
                                    temp3 = (temp1 + temp2)**2
                                    temp4 = 1.0*temp1
                                    temp5 = 1.0*temp2
                                    temp6 = u_1*v_1/(temp4*x1 + temp5*x1)**2
                                    contribution_v_1_u_1_0bdquykp += 1.0*sqrt(temp0*(temp4 + temp5)**2)*(-2.25*temp0*temp3*(temp4*temp6 + temp5*temp6) + u_1_x1*v_1_x1)/(temp0*temp3)
                                
                            
                            l_mat_u_1_v_1_0bdquykp[i_basis_1,i_basis_2,2 - i_basis_1 + j_basis_1,1 - i_basis_2 + j_basis_2] = contribution_v_1_u_1_0bdquykp
                        
                    
                
            
            g_mat_u_0_v_0_0bdquykp[pad1 + span_v_0_1 - test_v_0_p1:1 + pad1 + span_v_0_1,pad2 + span_v_0_2 - test_v_0_p2:1 + pad2 + span_v_0_2,:,:] += l_mat_u_0_v_0_0bdquykp[:,:,:,:]
            g_mat_u_1_v_0_0bdquykp[pad1 + span_v_0_1 - test_v_0_p1:1 + pad1 + span_v_0_1,pad2 + span_v_0_2 - test_v_0_p2:1 + pad2 + span_v_0_2,:,:] += l_mat_u_1_v_0_0bdquykp[:,:,:,:]
            g_mat_u_0_v_1_0bdquykp[pad1 + span_v_1_1 - test_v_1_p1:1 + pad1 + span_v_1_1,pad2 + span_v_1_2 - test_v_1_p2:1 + pad2 + span_v_1_2,:,:] += l_mat_u_0_v_1_0bdquykp[:,:,:,:]
            g_mat_u_1_v_1_0bdquykp[pad1 + span_v_1_1 - test_v_1_p1:1 + pad1 + span_v_1_1,pad2 + span_v_1_2 - test_v_1_p2:1 + pad2 + span_v_1_2,:,:] += l_mat_u_1_v_1_0bdquykp[:,:,:,:]
        
    
    return