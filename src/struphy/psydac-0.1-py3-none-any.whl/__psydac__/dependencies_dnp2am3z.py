
def assemble_vector_dnp2am3z(global_test_basis_v_1, global_test_basis_v_2, global_span_v_1, global_span_v_2, global_x1, global_x2, test_v_p1, test_v_p2, n_element_1, n_element_2, k1, k2, pad1, pad2, g_vec_v_dnp2am3z):

    from numpy import array, zeros, zeros_like, floor
    from math import sin, cos, pi
    local_x1 = zeros_like(global_x1[0,:])
    local_x2 = zeros_like(global_x2[0,:])
    
    l_vec_v_dnp2am3z = zeros((3, 3), dtype='float64')
    i_element_2 = 0
    local_x2[:] = global_x2[i_element_2,:]
    span_v_2 = global_span_v_2[i_element_2]
    for i_element_1 in range(0, n_element_1, 1):
        local_x1[:] = global_x1[i_element_1,:]
        span_v_1 = global_span_v_1[i_element_1]
        for i_basis_1 in range(0, 1 + test_v_p1, 1):
            for i_basis_2 in range(0, 1 + test_v_p2, 1):
                contribution_v_dnp2am3z = 0.0
                i_quad_2 = 0
                x2 = local_x2[i_quad_2]
                v_2 = global_test_basis_v_2[i_element_2,i_basis_2,0,i_quad_2]
                v_2_x2 = global_test_basis_v_2[i_element_2,i_basis_2,1,i_quad_2]
                for i_quad_1 in range(0, 3, 1):
                    x1 = local_x1[i_quad_1]
                    v_1 = global_test_basis_v_1[i_element_1,i_basis_1,0,i_quad_1]
                    v_1_x1 = global_test_basis_v_1[i_element_1,i_basis_1,1,i_quad_1]
                    v = v_1*v_2
                    v_x2 = v_1*v_2_x2
                    v_x1 = v_1_x1*v_2
                    nn_0 = 0
                    nn_1 = -1
                    temp0 = pi*x1
                    temp1 = pi*x2
                    contribution_v_dnp2am3z += v*(-pi*nn_0*sin(temp0)*cos(temp1) - pi*nn_1*sin(temp1)*cos(temp0))
                
                l_vec_v_dnp2am3z[i_basis_1,i_basis_2] = contribution_v_dnp2am3z
            
        
        g_vec_v_dnp2am3z[pad1 + span_v_1 - test_v_p1:1 + pad1 + span_v_1,pad2 + span_v_2 - test_v_p2:1 + pad2 + span_v_2] += l_vec_v_dnp2am3z[:,:]
    
    return