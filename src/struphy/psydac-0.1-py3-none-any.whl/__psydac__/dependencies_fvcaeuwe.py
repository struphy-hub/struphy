
def assemble_vector_fvcaeuwe(global_test_basis_v_1, global_test_basis_v_2, global_test_basis_mapping_v_1, global_test_basis_mapping_v_2, global_span_v_1, global_span_v_2, global_span_mapping_v_1, global_span_mapping_v_2, global_x1, global_x2, test_v_p1, test_v_p2, test_mapping_v_p1, test_mapping_v_p2, n_element_1, n_element_2, k1, k2, pad1, pad2, global_arr_coeffs_x, global_arr_coeffs_y, g_vec_v_fvcaeuwe):

    from numpy import array, zeros, zeros_like, floor
    from math import sin, pi, sqrt
    local_x1 = zeros_like(global_x1[0,:])
    local_x2 = zeros_like(global_x2[0,:])
    arr_coeffs_x = zeros((1 + test_mapping_v_p1, 1 + test_mapping_v_p2), dtype='float64')
    arr_coeffs_y = zeros((1 + test_mapping_v_p1, 1 + test_mapping_v_p2), dtype='float64')
    arr_x = zeros((3, 3), dtype='float64')
    arr_x_x2 = zeros((3, 3), dtype='float64')
    arr_x_x1 = zeros((3, 3), dtype='float64')
    arr_y = zeros((3, 3), dtype='float64')
    arr_y_x2 = zeros((3, 3), dtype='float64')
    arr_y_x1 = zeros((3, 3), dtype='float64')
    
    l_vec_v_fvcaeuwe = zeros((3, 3), dtype='float64')
    for i_element_1 in range(0, n_element_1, 1):
        local_x1[:] = global_x1[i_element_1,:]
        span_v_1 = global_span_v_1[i_element_1]
        span_mapping_v_1 = global_span_mapping_v_1[i_element_1]
        for i_element_2 in range(0, n_element_2, 1):
            local_x2[:] = global_x2[i_element_2,:]
            span_v_2 = global_span_v_2[i_element_2]
            span_mapping_v_2 = global_span_mapping_v_2[i_element_2]
            arr_y[:,:] = 0.0
            arr_x_x2[:,:] = 0.0
            arr_x_x1[:,:] = 0.0
            arr_y_x2[:,:] = 0.0
            arr_y_x1[:,:] = 0.0
            arr_x[:,:] = 0.0
            arr_coeffs_x[:,:] = global_arr_coeffs_x[2 + span_mapping_v_1 - test_mapping_v_p1:3 + span_mapping_v_1,2 + span_mapping_v_2 - test_mapping_v_p2:3 + span_mapping_v_2]
            arr_coeffs_y[:,:] = global_arr_coeffs_y[2 + span_mapping_v_1 - test_mapping_v_p1:3 + span_mapping_v_1,2 + span_mapping_v_2 - test_mapping_v_p2:3 + span_mapping_v_2]
            for i_quad_1 in range(0, 3, 1):
                for i_quad_2 in range(0, 3, 1):
                    for i_basis_1 in range(0, 3, 1):
                        mapping_v_1 = global_test_basis_mapping_v_1[i_element_1,i_basis_1,0,i_quad_1]
                        mapping_v_1_x1 = global_test_basis_mapping_v_1[i_element_1,i_basis_1,1,i_quad_1]
                        for i_basis_2 in range(0, 3, 1):
                            mapping_v_2 = global_test_basis_mapping_v_2[i_element_2,i_basis_2,0,i_quad_2]
                            mapping_v_2_x2 = global_test_basis_mapping_v_2[i_element_2,i_basis_2,1,i_quad_2]
                            coeff_x = arr_coeffs_x[i_basis_1,i_basis_2]
                            coeff_y = arr_coeffs_y[i_basis_1,i_basis_2]
                            mapping_v_x2 = mapping_v_1*mapping_v_2_x2
                            mapping_v = mapping_v_1*mapping_v_2
                            mapping_v_x1 = mapping_v_1_x1*mapping_v_2
                            arr_x[i_quad_1,i_quad_2] += mapping_v*coeff_x
                            arr_x_x2[i_quad_1,i_quad_2] += mapping_v_x2*coeff_x
                            arr_x_x1[i_quad_1,i_quad_2] += mapping_v_x1*coeff_x
                            arr_y[i_quad_1,i_quad_2] += mapping_v*coeff_y
                            arr_y_x2[i_quad_1,i_quad_2] += mapping_v_x2*coeff_y
                            arr_y_x1[i_quad_1,i_quad_2] += mapping_v_x1*coeff_y
                        
                    
                
            
            for i_basis_1 in range(0, 1 + test_v_p1, 1):
                for i_basis_2 in range(0, 1 + test_v_p2, 1):
                    contribution_v_fvcaeuwe = 0.0
                    for i_quad_1 in range(0, 3, 1):
                        x1 = local_x1[i_quad_1]
                        v_1 = global_test_basis_v_1[i_element_1,i_basis_1,0,i_quad_1]
                        v_1_x1 = global_test_basis_v_1[i_element_1,i_basis_1,1,i_quad_1]
                        for i_quad_2 in range(0, 3, 1):
                            x2 = local_x2[i_quad_2]
                            v_2 = global_test_basis_v_2[i_element_2,i_basis_2,0,i_quad_2]
                            v_2_x2 = global_test_basis_v_2[i_element_2,i_basis_2,1,i_quad_2]
                            x = arr_x[i_quad_1,i_quad_2]
                            x_x2 = arr_x_x2[i_quad_1,i_quad_2]
                            x_x1 = arr_x_x1[i_quad_1,i_quad_2]
                            y = arr_y[i_quad_1,i_quad_2]
                            y_x2 = arr_y_x2[i_quad_1,i_quad_2]
                            y_x1 = arr_y_x1[i_quad_1,i_quad_2]
                            v = v_1*v_2
                            v_x2 = v_1*v_2_x2
                            v_x1 = v_1_x1*v_2
                            contribution_v_fvcaeuwe += 2*pi**2*v*sqrt((x_x1*y_x2 - x_x2*y_x1)**2)*sin(pi*x)*sin(pi*y)
                        
                    
                    l_vec_v_fvcaeuwe[i_basis_1,i_basis_2] = contribution_v_fvcaeuwe
                
            
            g_vec_v_fvcaeuwe[pad1 + span_v_1 - test_v_p1:1 + pad1 + span_v_1,pad2 + span_v_2 - test_v_p2:1 + pad2 + span_v_2] += l_vec_v_fvcaeuwe[:,:]
        
    
    return