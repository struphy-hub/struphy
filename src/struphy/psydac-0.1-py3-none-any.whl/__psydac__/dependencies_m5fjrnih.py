from pyccel.decorators import types
from numpy import shape
@types("float64[:,:,:,:]", "float64[:,:]", "float64[:,:]", "int64", "int64", "int64", "int64")
def lo_dot_m5fjrnih(mat00, x0, out0, s00_1, s00_2, n00_1, n00_2):

    
    for i1 in range(0, n00_1, 1):
        for i2 in range(0, n00_2, 1):
            v00 = 0.0
            for k1 in range(0, 5, 1):
                for k2 in range(0, 7, 1):
                    v00 += mat00[2 + i1,3 + i2,k1,k2]*x0[i1 + k1,i2 + k2]
                
            
            out0[2 + i1,3 + i2] = v00
        
    
    return