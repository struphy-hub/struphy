from pyccel.decorators import types
from numpy import shape
@types("float64[:,:]", "float64[:]", "float64[:]", "int64", "int64")
def lo_dot_q37a1csv(mat00, x0, out0, s00_1, n00_1):

    
    for i1 in range(0, n00_1, 1):
        v00 = 0.0
        for k1 in range(0, 3, 1):
            v00 += mat00[1 + i1,k1]*x0[i1 + k1]
        
        out0[1 + i1] = v00
    
    return