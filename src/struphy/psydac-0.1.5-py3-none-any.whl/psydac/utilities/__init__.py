__all__ = ['quadratures']

from psydac.utilities import quadratures
